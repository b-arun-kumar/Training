package com.finaldemo.demo1

class Lab1 {

}
fun main(){
    println("Hello World !!!")
}