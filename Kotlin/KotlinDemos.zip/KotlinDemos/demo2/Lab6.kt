package com.finaldemo.demo2

fun main(args: Array<String>) {
    try {
        print("Enter your name :")
        val name = readLine()
        print("Enter your age :")

        var age: Int = Integer.valueOf(readLine())
        println("Your name is $name and your age is $age")
    }catch (e: Exception)
    {
        println("Some Error " + e.message)
    }
    finally {
        println("finally - Message for try or catch both")
    }
}