package com.finaldemo.demo2

class Lab3 {
}

fun main() {
    val number1 = mutableListOf(1, 2, 3, 4)
    val number2 = mutableListOf(5,6,7,8)
    val numbers = number1+number2
    println(numbers)
}