package com.finaldemo.demo2.dbcon

import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.Statement

fun main(args: Array<String>) {
    val repo= MySQLCrudRepo()
    for(i in 1..10)
    {
        repo.create(Dept(i,"Dname $i",if (i %2 ==0) "Hyd" else "Pune"))
    }
    /*val d:Dept = Dept(2,dname = "ddd",loc="loc")
    print("Returned for delete =  ${repo.delete(d)}");
    val d1:Dept = Dept(1,dname = "HR",loc="Blr")
    repo.update(d1);*/
    val list = repo.list()
    for ( d in list)
        println(d)

}

class MySQLCrudRepo{

    //val classname="com.mysql.jdbc.Driver"
    val classname="com.mysql.cj.jdbc.Driver"
    fun opencon(url:String="jdbc:mysql://database-1.chidkemxak9r.us-east-1.rds.amazonaws.com:3306/test",user:String="admin",password:String="mypassword"):Connection{
        //Class.forName(classname);
        return DriverManager.getConnection(url,user,password);
    }
    fun create(dept: Dept){
        val con:Connection = opencon()
        val stmt:Statement = con.createStatement();
        val sql = "insert into dept values (${dept.deptno},'${dept.dname}','${dept.loc}')"
        println(sql)
        stmt.execute(sql)
        println("inserted")
        con.close()
    }
    fun update(dept: Dept){
        val con:Connection = opencon()
        val stmt:Statement = con.createStatement();
        val sql = " update dept set dname='${dept.dname}' , loc='${dept.loc}' where deptno  = ${dept.deptno}"
        println(sql)
        stmt.execute(sql)
        println("updated")
        con.close()
    }
    fun delete(dept:Dept):Boolean{
        val con:Connection = opencon()
        val sql = " delete from dept where deptno  = ${dept.deptno}"
        val stmt:Statement = con.createStatement();
        println(sql)
        val bool= stmt.execute(sql)
        println("deleted")
        con.close()
        return bool
    }
    fun list():List<Dept>
    {  val con:Connection = opencon()
        val sql = " select * from dept"
        val stmt:Statement = con.createStatement();
        val rs:ResultSet =stmt.executeQuery(sql)
        //var list: MutableList<ArrayList<Dept>> = MutableList<ArrayList<Dept>>(size = 10,init = null);
        val list: MutableList<Dept> = ArrayList()
        while(rs.next())
        {
            val d:Dept = Dept(deptno = rs.getInt(1),dname=rs.getString(2),loc=rs.getString(3))
            list.add(d)
        }
        con.close()
        return list;
    }
}
//sdata class Dept(val deptno: Int, val dname:String,val loc:String);
