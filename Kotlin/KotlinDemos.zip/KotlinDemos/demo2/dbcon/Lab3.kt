package com.finaldemo.demo2.dbcon

import com.mongodb.client.MongoClient
import org.litote.kmongo.*

data class Emp(val empno: Int, val ename:String,val salary:Double);

class MongoCRUDRepo {
    fun createclient(): MongoClient {

      //  val constr=  "mongodb+srv://dbuser:mypassword@mycluster.exzwx.mongodb.net/mycluster?retryWrites=true&w=majority"
      val constr=  "mongodb+srv://dbuser11:9DeA7H3NV0taVwEW@mycluster.exzwx.mongodb.net/mycluster?retryWrites=true&w=majority"
      return KMongo.createClient(constr);
    }

    fun create(emp: Emp) {
        println("Create " +emp)
        val client =createclient();
        val database = client.getDatabase("db")
        val col = database.getCollection<Emp>()
        col.insertOne(emp)
        client.close()
    }

    fun list(){
        println("List")
        val client =createclient();
        val database = client.getDatabase("db")
        val col = database.getCollection<Emp>()
        for (emp in col.find())
            println(emp)
        client.close()
    }

    fun delete(empno:Int){
        println("delete")
        val client =createclient();
        val database = client.getDatabase("db")
        val col = database.getCollection<Emp>()
        col.deleteOne("{'empno':$empno}")
        client.close()
    }
}
fun main(){
  val repo = MongoCRUDRepo()
    val i = 1
    val e = Emp(i, "Name$i", i * 1000.0)
        repo.create(e)
    repo.list()
    repo.delete(1)
    repo.list()
}
