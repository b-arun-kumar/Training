package com.finaldemo.demo2.dbcon

import java.sql.Connection
import java.sql.DriverManager

data class Dept (var deptno: Int = 0, var dname: String = "", var loc: String = "") {}

class DbOperations{


    fun open(url:String="jdbc:mysql://database-1.chidkemxak9r.us-east-1.rds.amazonaws.com:3306/test",
             uname:String="admin",
             pwd:String="mypassword"
             ): Connection {
          return DriverManager.getConnection(url,uname,pwd)
    }
    fun create(d:Dept){
        var con:Connection? = null
        try {
            con = open()
            val sql = "insert into dept values ( ${d.deptno}, '${d.dname}', '${d.loc}' )"
            println("in create - $sql")
            val stmt = con?.createStatement()
            val rs = stmt?.execute(sql)
        } catch (e: Exception) {
            println("Create: Error is " + (e.message ?: "Unknown"))
        } finally {
            con?.close()
        }


    }
    fun list(){
        val con = open()
        val sql = "select * from dept"
        val stmt = con.createStatement()
        val rs = stmt.executeQuery(sql)

        while(rs.next()) {
            println("Deptno : ${rs.getInt(1)}, DName :  ${rs.getString(2)}, Loc : ${rs.getString(3)} ")
        }
        con.close()
    }
    fun delete(deptno:Int){
        val con = open()
        try {
            val sql = "delete from dept where deptno=${deptno}"
            val stmt = con.createStatement()
            val rs = stmt.execute(sql)
        } catch (e: Exception) {
            println("Delete: Error is " + (e.message ?: "Unknown"))
        } finally {
            con.close()
        }
    }
    fun update(d: Dept) {
        val con = open()
        try {
            val sql = "update dept set deptno = '${d.deptno}', dname = '${d.dname}', loc = '${d.loc}' where deptno = '${d.deptno}'"
            val stmt = con.createStatement()
            val rs = stmt.execute(sql)
        } catch (e: Exception) {
            println("Update: Error is " + (e.message ?: "Unknown"))
        } finally {
            con.close()
        }
    }


}
fun main(){
    val d = Dept(11,"Vaishali",loc = "Pune")
    val dbops = DbOperations()
    dbops.create(d)
    dbops.list()
}
