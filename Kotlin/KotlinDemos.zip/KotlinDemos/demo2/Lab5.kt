package com.finaldemo.demo2


data class Department (var no: Int = 0, var name: String = "", var loc: String = "") {}

class DeptManager {
    var depts:MutableList<Department> = mutableListOf()
    fun add(dept: Department) {
        depts.add(dept)
    }
}
fun DeptManager.print(){
    for (d in this.depts)
        println(d)
}
fun main() {
    val manager = DeptManager()
    for (i in 0..4){
        val d = Department(i+1, "AAA"+i, if ( i % 2 ==0) "Hyd" else "Pune")
        manager.add(d)
    }
    manager.print()
    println("-------------------From Hyd-----------------")
    manager.depts.filter { d-> if (d.loc=="Hyd") true else false }.forEach{d1->println(d1)}
    println("-------------------From Department number-----------------")
    manager.depts.filter { d-> d.name.length >5 || d.no !in 3..5 }.forEach{d1->println(d1)}
    println("-------------------From Department numbers-----------------")
    manager.depts.filter { d-> ((d.name.length > 5) || (d.no > 2 && d.no < 5))}.forEach{d1->println(d1)}


}
