package com.finaldemo.demo

data class Department (var no: Int = 0, var name: String = "", var loc: String = "") {}

class DeptManager {
    private val arraySize: Int = 5
    val depts = Array<Department>(arraySize){i -> Department()}

    fun add(dept: Department) {
        depts[depts.count() - 1] = dept
    }
}
fun DeptManager.print(){
    for (d in this.depts)
        println(d)
}
fun main() {
    val manager = DeptManager()
    val d = Department(100, "Mahesh", "200")
    manager.add(d)
    manager.print()

}
