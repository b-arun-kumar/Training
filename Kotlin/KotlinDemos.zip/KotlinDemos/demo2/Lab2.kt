package com.finaldemo.demo2

data class Emp (var empno:Int,var ename:String) {
    // properties + toString + equals + hash + componentN
}

fun main(){
    val e1 = Emp(10,"AA")
    var e2 = Emp(20,"BB")
    println(e1)
    println(e2)
    val (empno:Int, ename:String) = e1
    println("Empno = " + empno + ", Ename = "+ ename)
    e2 = Emp(empno,ename)
    println(e2)
}