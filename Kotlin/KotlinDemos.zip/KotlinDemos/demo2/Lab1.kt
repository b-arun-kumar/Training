package com.finaldemo.demo2

fun main(){
    println("Hello")
    val s:String  = "aaa"
    println(s)
    s.shout()
}
fun String.shout():String{
    println("shout invoked ...")
    return this.uppercase();
 }
