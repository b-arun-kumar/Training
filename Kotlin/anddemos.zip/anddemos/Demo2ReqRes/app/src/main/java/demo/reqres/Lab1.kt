package demo.reqres


import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.net.URL

@Serializable
data class User(val userId:Int, val id:Int,val title:String,val completed:Boolean)
fun main() {
    println("Remote Call")
    val dataList = listOf(User(42, 1,title="King",true), User(43, 2,title="Noble",true))
    println("SimpleObj"+ Json.encodeToString(User(42, 1,title="King",true)))

    val jsonList = Json.encodeToString(dataList)
    println("List  = $jsonList" )

    val url = URL("https://jsonplaceholder.typicode.com/todos/1")
    val content = url.getContent() // pointer to url(httpUrlCOnnection)
    println("Content = $content")
    val jsontext = url.readText()
    println(jsontext)

    val obj = Json.decodeFromString<User>("""
        $jsontext
        """)
    println(obj)
    println(obj.title)
}
