package and.demo.demo4
import kotlinx.serialization.Serializable


@Serializable
data class UserInput(val name:String, val job:String)
@Serializable
data class UserOutput(val name:String, val job:String,val id:String, val createdAt:String )
@Serializable
data class User(val id: Int, val email:String, val first_name:String, val last_name:String, val avatar:String)
@Serializable
data class UsersCollection(val page:Int=0, val per_page:Int=0, val total:Int=0, val total_pages:Int=0, val data:List<User>)
