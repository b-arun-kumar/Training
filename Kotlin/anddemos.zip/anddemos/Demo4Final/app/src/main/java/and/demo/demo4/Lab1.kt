package and.demo.demo4
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() = runBlocking()
{
    println("starting of main")
    val str = readLine()
    launch { // launch a new coroutine and continue
        println("\n\nstart of launch1")
        for ( i in (1..5000))
            print("l1- $i")
        println("\n\nend of launch1")
    }
    launch { // launch a new coroutine and continue
        println("\n\nstart of launch2")
        for ( i in (1..5))
            print("l2- $i")
        println("\n\nend of launch2")
    }
    Thread.sleep(1000)
    println("Hello") // main coroutine continues while a previous one is delayed
}
