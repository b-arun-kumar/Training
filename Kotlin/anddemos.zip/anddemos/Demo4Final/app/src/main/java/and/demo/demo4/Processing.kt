package and.demo.demo4

import android.R
import com.github.kittinunf.fuel.Fuel

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonConfiguration
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL

class ItemsProcessor
{
   suspend fun get(pagenumber:Int):UsersCollection{
        val myURL = URL("https://reqres.in/api/users?page="+pagenumber)
        val httpcon = myURL.openConnection()
        httpcon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        httpcon.setRequestProperty("Content-Language", "en-US")
        httpcon.setRequestProperty("user-agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36")
        val inps = InputStreamReader(httpcon.getInputStream())
        val buff = BufferedReader(inps)
        var str= ""
        var line: String?
        do {
            line = buff.readLine()
            str+= line?:""
        } while (line != null)
        println(str)
        val obj = Json.decodeFromString(UsersCollection.serializer(),str);
        println("obj"  + obj)
        return obj;
    }
}

class UserProcessor {
    suspend fun create(userInput: UserInput): UserOutput {
        val url = "https://reqres.in/api/users";
        val pair1 = Pair("name",userInput.name);
        val pair2 = Pair("job",userInput.job);
        val list = listOf(pair1,pair2)

        val (request, response, result) = Fuel
            .post(url, list)
            .header(mapOf("user-agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36"))
            .responseString()
        println(result.get())

        val obj = Json.decodeFromString(UserOutput.serializer(),result.get())
        return  obj
    }
}
