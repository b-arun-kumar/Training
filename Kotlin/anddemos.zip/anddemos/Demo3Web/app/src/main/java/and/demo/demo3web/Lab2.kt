package and.demo.demo3web


import org.http4k.core.*
import org.http4k.core.Method.GET
import org.http4k.core.Method.POST
import org.http4k.core.Status.Companion.OK
import org.http4k.filter.DebuggingFilters.PrintRequest
import org.http4k.routing.bind
import org.http4k.routing.routes
import org.http4k.server.KtorNetty
import org.http4k.core.then
import org.http4k.core.with
import org.http4k.server.asServer
import org.http4k.format.KotlinxSerialization.number
import org.http4k.format.KotlinxSerialization.obj
import org.http4k.format.KotlinxSerialization.string
import org.http4k.format.KotlinxSerialization.json

val kotlinXMessageLens = Body.json().toLens()

val kotlinXMessage = obj(
    "empno" to number(1),
    "ename" to string("Vaishali"),
    "salary" to number(123),

)

val app: HttpHandler = routes(
    "/ping" bind GET to {
        Response(OK).body("Pong")
    },
    "/ping" bind POST to {
        Response(OK).body("Post Pong")
    },
    "/json" bind GET to {
        Response(OK).with( kotlinXMessageLens of kotlinXMessage)
    }
)

fun main() {
    val printingApp: HttpHandler = PrintRequest().then(app)

    val server = printingApp.asServer(KtorNetty(8080)).start()

    println("Server started on " + server.port())
}
