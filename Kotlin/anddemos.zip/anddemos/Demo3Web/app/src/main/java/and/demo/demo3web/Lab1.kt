package and.demo.demo3web
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.server.SunHttp
import org.http4k.server.asServer

fun main(args: Array<String>) {
    var app : HttpHandler= {req:Request ->
        println("method =  ${req.method}" )
        Response(Status.OK).body("<H1 >Hello, " +
                "${req.query("nm")}</H1>")
    }
    val server = app.asServer(SunHttp(8000)).start()

}

